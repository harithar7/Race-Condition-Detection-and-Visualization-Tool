"""
Race Condition Analysis Engine (pure Python, no external deps).
Detects shared-variable RW / WW conflicts in C, C++, Python, Java code.
"""

import re
from typing import Any, Dict, List

LANG_PATTERNS = {
    "c": [r"pthread_create", r"#include\s*<pthread", r"\bvoid\s*\*\s*\w+\s*\("],
    "cpp": [r"std::thread", r"#include\s*<thread>", r"std::mutex"],
    "python": [r"import\s+threading", r"threading\.Thread", r"def\s+\w+\s*\("],
    "java": [
        r"implements\s+Runnable",
        r"extends\s+Thread",
        r"synchronized",
        r"class\s+\w+",
    ],
    "go": [r"go\s+func", r"sync\.Mutex", r"import\s+\"sync\"", r"package\s+main"],
    "rust": [r"std::thread", r"std::sync::Mutex", r"fn\s+main\(\)", r"Arc::new"],
}

LOCK_PATTERNS = [
    r"pthread_mutex_lock",
    r"\.lock\s*\(",
    r"std::lock_guard",
    r"std::unique_lock",
    r"\bsynchronized\b",
    r"with\s+\w*lock\w*\b",
    r"\bacquire\s*\(",
    r"\.[Ll]ock\s*\(",
]
UNLOCK_PATTERNS = [
    r"pthread_mutex_unlock",
    r"\.unlock\s*\(",
    r"\brelease\s*\(",
    r"\.[Uu]nlock\s*\(",
]


def detect_language(code: str) -> str:
    scores = {k: 0 for k in LANG_PATTERNS}
    for lang, pats in LANG_PATTERNS.items():
        for p in pats:
            if re.search(p, code):
                scores[lang] += 1
    if re.search(r"\bdef\s+\w+\s*\(", code) and scores["python"] == 0:
        scores["python"] = 1
    if re.search(r"std::", code):
        scores["cpp"] += 1
    best = max(scores.items(), key=lambda x: x[1])
    return best[0] if best[1] > 0 else "c"


def find_shared_variables(code: str, lang: str) -> List[str]:
    shared = set()
    lines = code.split("\n")
    if lang == "python":
        for l in lines:
            m = re.match(r"^([A-Za-z_]\w*)\s*=\s*[^=]", l)
            if m:
                shared.add(m.group(1))
        for m in re.finditer(r"\bglobal\s+([\w,\s]+)", code):
            for v in m.group(1).split(","):
                v = v.strip()
                if v:
                    shared.add(v)
    elif lang in ("c", "cpp"):
        for l in lines:
            m = re.match(
                r"^(?:static\s+|extern\s+|volatile\s+)*"
                r"(?:int|long|short|char|float|double|bool|size_t|unsigned|atomic_int)"
                r"\s+([A-Za-z_]\w*)\s*[=;\[]",
                l,
            )
            if m:
                shared.add(m.group(1))
    elif lang == "java":
        for m in re.finditer(
            r"\b(?:private|public|protected|static)\s+(?:static\s+)?"
            r"(?:int|long|double|float|boolean|String|[A-Z]\w*)\s+([A-Za-z_]\w*)\s*[=;]",
            code,
        ):
            shared.add(m.group(1))
    elif lang == "go":
        for m in re.finditer(
            r"(?:var\s+)?([A-Za-z_]\w*)\s*(?:int|float64|bool|string)?\s*(?:=|:=)", code
        ):
            shared.add(m.group(1))
        for m in re.finditer(
            r"var\s+([A-Za-z_]\w*)\s+(?:int|float64|bool|string)", code
        ):
            shared.add(m.group(1))
    elif lang == "rust":
        for m in re.finditer(
            r"(?:let\s+)?(?:mut\s+)?([A-Za-z_]\w*)\s*=\s*(?:Arc::new|Mutex::new|0|1)",
            code,
        ):
            shared.add(m.group(1))
        for m in re.finditer(r"static\s+(?:mut\s+)?([A-Za-z_]\w*)\s*:", code):
            shared.add(m.group(1))
    for v in ("i", "j", "k", "tmp", "temp", "argc", "argv", "self", "this"):
        shared.discard(v)
    return sorted(shared)


def find_threads(code: str, lang: str) -> List[str]:
    threads = set()
    if lang == "python":
        for m in re.finditer(
            r"threading\.Thread\s*\(\s*target\s*=\s*([A-Za-z_]\w*)", code
        ):
            threads.add(m.group(1))
    elif lang in ("c", "cpp"):
        for m in re.finditer(r"pthread_create\s*\([^,]+,[^,]+,\s*([A-Za-z_]\w*)", code):
            threads.add(m.group(1))
        for m in re.finditer(r"std::thread\s+\w+\s*\(\s*([A-Za-z_]\w*)", code):
            threads.add(m.group(1))
    elif lang == "java":
        for m in re.finditer(r"new\s+Thread\s*\(\s*new\s+([A-Za-z_]\w*)", code):
            threads.add(m.group(1))
        for m in re.finditer(
            r"class\s+(\w+)\s+(?:extends\s+Thread|implements\s+Runnable)", code
        ):
            threads.add(m.group(1))
    elif lang == "go":
        for m in re.finditer(r"go\s+([A-Za-z_]\w*)\s*\(", code):
            threads.add(m.group(1))
        if re.search(r"go\s+func", code):
            threads.add("Goroutine")
    elif lang == "rust":
        for m in re.finditer(r"thread::spawn", code):
            threads.add("SpawnedThread")
    if not threads:
        threads = {"Thread-A", "Thread-B"}
    return sorted(threads)


def _is_lock(line: str) -> bool:
    return any(re.search(p, line) for p in LOCK_PATTERNS)


def _is_unlock(line: str) -> bool:
    return any(re.search(p, line) for p in UNLOCK_PATTERNS)


def scan_accesses(
    code: str, shared_vars: List[str], threads: List[str]
) -> List[Dict[str, Any]]:
    lines = code.split("\n")
    accesses = []
    lock_depth = 0
    idx = 0

    lock_indents = []

    for i, raw in enumerate(lines):
        line = re.sub(r"//.*$|#.*$", "", raw)

        # Check python indentation for block-based locks like `with lock:`
        stripped = raw.lstrip()
        if stripped and lock_indents:
            indent = len(raw) - len(stripped)
            if indent <= lock_indents[-1] and not stripped.startswith("#"):
                while lock_indents and indent <= lock_indents[-1]:
                    lock_indents.pop()
                    lock_depth = max(0, lock_depth - 1)

        if _is_lock(line):
            lock_depth += 1
            if re.search(r"\bwith\s+", line):
                lock_indents.append(len(raw) - len(stripped))

        if (
            re.search(r"\bsynchronized\s*\(", line)
            or re.search(r"lock_guard|unique_lock", line)
            or re.search(r"\.lock\(\)\.unwrap\(\)", line)
        ):
            lock_depth = max(lock_depth, 1)

        for v in shared_vars:
            if not re.search(rf"\b{v}\b", line):
                continue
            write_re = rf"\b{v}\s*(?:\+\+|--|\+=|-=|\*=|/=|=)(?:[^=]|$)"
            is_write = bool(re.search(write_re, line)) or bool(
                re.search(rf"(?:\+\+|--)\s*{v}\b", line)
            )
            accesses.append(
                {
                    "variable": v,
                    "line": i + 1,
                    "type": "write" if is_write else "read",
                    "thread": threads[idx % len(threads)],
                    "insideLock": lock_depth > 0,
                }
            )
            idx += 1

        if _is_unlock(line):
            lock_depth = max(0, lock_depth - 1)
        if re.match(r"^\s*}", line) and lock_depth > 0:
            lock_depth = max(0, lock_depth - 1)

    return accesses


def build_conflicts(accesses, lines):
    by_var: Dict[str, List[Dict]] = {}
    for a in accesses:
        by_var.setdefault(a["variable"], []).append(a)
    conflicts = []
    for v, lst in by_var.items():
        writes = [a for a in lst if a["type"] == "write" and not a["insideLock"]]
        reads = [a for a in lst if a["type"] == "read" and not a["insideLock"]]
        if not writes:
            continue
        ww = len(writes) >= 2
        rw = len(writes) >= 1 and len(reads) >= 1
        if not (ww or rw):
            continue
        involved = writes[:4] if ww else writes[:2] + reads[:2]
        threads = sorted({a["thread"] for a in involved})
        line_nums = sorted({a["line"] for a in involved})
        snippet = "\n".join(
            f"{str(n).rjust(3)} | {lines[n-1] if n-1 < len(lines) else ''}"
            for n in line_nums[:5]
        )
        if ww:
            suggestion = (
                f"Two or more threads write to '{v}' without synchronization. "
                f"Wrap writes in a mutex (pthread_mutex_lock/unlock, std::lock_guard, "
                f"threading.Lock, or 'synchronized'), or convert '{v}' to an atomic type "
                f"(atomic_int / std::atomic / AtomicInteger)."
            )
        else:
            suggestion = (
                f"Reads and writes of '{v}' from multiple threads can interleave. "
                f"Protect the read-modify-write sequence with a mutex, or use an atomic "
                f"if only single load/store is needed."
            )
        conflicts.append(
            {
                "variable": v,
                "lines": line_nums,
                "threads": threads,
                "kind": "WW" if ww else "RW",
                "severity": "high" if ww else "medium",
                "snippet": snippet,
                "suggestion": suggestion,
            }
        )
    return conflicts


def build_events(accesses, conflicts):
    cvars = {c["variable"] for c in conflicts}
    return [
        {
            "step": i + 1,
            "thread": a["thread"],
            "variable": a["variable"],
            "action": a["type"],
            "line": a["line"],
            "conflict": a["variable"] in cvars and not a["insideLock"],
        }
        for i, a in enumerate(accesses[:80])
    ]


def build_suggestions(conflicts, lang):
    if not conflicts:
        return [
            "No race conditions detected by static heuristics. "
            "Verify with a runtime tool like ThreadSanitizer for full coverage."
        ]
    tips = []
    lang_tip = {
        "c": "Use pthread_mutex_t and pthread_mutex_lock/unlock around critical sections, or <stdatomic.h> atomics.",
        "cpp": "Prefer std::lock_guard<std::mutex> for RAII locking, or std::atomic<T> for primitive flags/counters.",
        "python": "Use threading.Lock() with a `with lock:` block. For counters, queue.Queue or multiprocessing.Value can also help.",
        "java": "Use the `synchronized` keyword on the method/block, or java.util.concurrent.atomic.AtomicInteger.",
        "go": "Use sync.Mutex with mu.Lock() and defer mu.Unlock(), or communicate via channels instead of sharing memory.",
        "rust": "Rust's borrow checker prevents safe data races, but inside `unsafe` blocks or when using `static mut`, use `Arc<Mutex<T>>`.",
    }
    tips.append(lang_tip.get(lang, ""))
    for c in conflicts:
        tips.append(f"Variable '{c['variable']}' ({c['kind']}): {c['suggestion']}")
    tips.append("Keep critical sections short to reduce contention.")
    tips.append("Always release locks on every code path (use RAII / try-finally).")
    seen = set()
    out = []
    for t in tips:
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def analyze(code: str, language: str = "auto") -> Dict[str, Any]:
    lang = detect_language(code) if language == "auto" else language
    lines = code.split("\n")
    shared = find_shared_variables(code, lang)
    threads = find_threads(code, lang)
    accesses = scan_accesses(code, shared, threads)
    conflicts = build_conflicts(accesses, lines)
    events = build_events(accesses, conflicts)
    suggestions = build_suggestions(conflicts, lang)
    score = max(0, 100 - sum(30 if c["severity"] == "high" else 15 for c in conflicts))
    return {
        "language": lang,
        "totalLines": len(lines),
        "threadsDetected": threads,
        "sharedVariables": shared,
        "accesses": accesses,
        "conflicts": conflicts,
        "events": events,
        "suggestions": suggestions,
        "score": score,
    }


EXAMPLES = {
    "c_counter": {
        "title": "C — Unsynchronized counter",
        "language": "c",
        "code": """#include <pthread.h>
#include <stdio.h>

int counter = 0;

void* worker(void* arg) {
    for (int i = 0; i < 100000; i++) {
        counter++;          // race: read-modify-write
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, worker, NULL);
    pthread_create(&t2, NULL, worker, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("counter = %d\\n", counter);
    return 0;
}
""",
    },
    "python_counter": {
        "title": "Python — Shared total, no lock",
        "language": "python",
        "code": """import threading

shared_total = 0
log = []

def producer():
    global shared_total
    for i in range(1000):
        shared_total += 1
        log.append(i)

def consumer():
    global shared_total
    for i in range(1000):
        shared_total -= 1

t1 = threading.Thread(target=producer)
t2 = threading.Thread(target=consumer)
t1.start(); t2.start()
t1.join();  t2.join()
print(shared_total)
""",
    },
    "java_counter": {
        "title": "Java — Two threads incrementing field",
        "language": "java",
        "code": """class Bank {
    public int balance = 0;

    public void deposit() {
        for (int i = 0; i < 10000; i++) {
            balance = balance + 1;
        }
    }
}

class Worker implements Runnable {
    Bank b;
    Worker(Bank b) { this.b = b; }
    public void run() { b.deposit(); }
}
""",
    },
    "go_counter": {
        "title": "Go — Goroutines data race",
        "language": "go",
        "code": """package main

import (
\t"fmt"
\t"sync"
)

var counter int = 0

func main() {
\tvar wg sync.WaitGroup
\tfor i := 0; i < 2; i++ {
\t\twg.Add(1)
\t\tgo func() {
\t\t\tfor j := 0; j < 1000; j++ {
\t\t\t\tcounter++ // race
\t\t\t}
\t\t\twg.Done()
\t\t}()
\t}
\twg.Wait()
\tfmt.Println(counter)
}
""",
    },
    "rust_counter": {
        "title": "Rust — unsafe static mut race",
        "language": "rust",
        "code": """use std::thread;

static mut COUNTER: i32 = 0;

fn main() {
    let mut handles = vec![];
    for _ in 0..2 {
        let handle = thread::spawn(|| {
            for _ in 0..10000 {
                unsafe {
                    COUNTER += 1; // race
                }
            }
        });
        handles.push(handle);
    }
    for handle in handles {
        handle.join().unwrap();
    }
    unsafe { println!("COUNTER = {}", COUNTER); }
}
""",
    },
}
