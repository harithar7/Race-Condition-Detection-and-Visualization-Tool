// === Race Condition Detection Tool — frontend JS ===

function initAnalyzePage() {
    const examples = JSON.parse(document.getElementById('examples-data').textContent);
    const codeEl = document.getElementById('code');
    const langEl = document.getElementById('language');
    const status = document.getElementById('status');

    document.getElementById('examplePicker').addEventListener('change', (e) => {
        const k = e.target.value;
        if (!k) return;
        codeEl.value = examples[k].code;
        langEl.value = examples[k].language;
        status.textContent = `Loaded example: ${examples[k].title}`;
        status.className = 'status ok';
    });

    document.getElementById('fileInput').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append('file', file);
        status.textContent = 'Uploading…';
        status.className = 'status';
        const res = await fetch('/api/upload', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.error) {
            status.textContent = '⚠ ' + data.error;
            status.className = 'status err';
        } else {
            codeEl.value = data.code;
            status.textContent = `Loaded ${data.filename}`;
            status.className = 'status ok';
        }
    });

    document.getElementById('analyzeBtn').addEventListener('click', async () => {
        const code = codeEl.value.trim();
        if (!code) {
            status.textContent = '⚠ Paste some code first.';
            status.className = 'status err';
            return;
        }
        status.textContent = '🔄 Analyzing…';
        status.className = 'status';
        const res = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code, language: langEl.value }),
        });
        const data = await res.json();
        if (data.error) {
            status.textContent = '⚠ ' + data.error;
            status.className = 'status err';
            return;
        }
        status.textContent = `✅ Done — ${data.conflicts.length} conflict(s) found. Redirecting…`;
        status.className = 'status ok';
        setTimeout(() => { window.location.href = '/results'; }, 600);
    });
}

function renderVisualization() {
    const report = JSON.parse(document.getElementById('report-data').textContent);
    const timeline = document.getElementById('timeline');
    const threads = report.threadsDetected;
    const events = report.events || [];

    // Build timeline rows
    const stepCount = events.length;
    threads.forEach(t => {
        const row = document.createElement('div');
        row.className = 'tl-row';
        const label = document.createElement('div');
        label.className = 'tl-label';
        label.textContent = t;
        row.appendChild(label);
        for (let s = 0; s < stepCount; s++) {
            const ev = events[s];
            const cell = document.createElement('div');
            cell.className = 'tl-cell';
            if (ev && ev.thread === t) {
                cell.classList.add(ev.action === 'write' ? 'tl-w' : 'tl-r');
                cell.textContent = ev.action === 'write' ? 'W' : 'R';
                cell.title = `${ev.thread} ${ev.action} ${ev.variable} @ line ${ev.line}`;
                if (ev.conflict) cell.classList.add('tl-conflict');
            }
            row.appendChild(cell);
        }
        timeline.appendChild(row);
    });

    // Variable access counts bar chart
    const counts = {};
    (report.accesses || []).forEach(a => { counts[a.variable] = (counts[a.variable] || 0) + 1; });
    const max = Math.max(1, ...Object.values(counts));
    const chart = document.getElementById('varChart');
    Object.entries(counts).sort((a,b) => b[1]-a[1]).forEach(([v, n]) => {
        const row = document.createElement('div');
        row.className = 'bar-row';
        row.innerHTML = `
            <div class="bar-name">${v}</div>
            <div class="bar-track"><div class="bar-fill" style="width:${(n/max)*100}%">${n}</div></div>`;
        chart.appendChild(row);
    });
}
