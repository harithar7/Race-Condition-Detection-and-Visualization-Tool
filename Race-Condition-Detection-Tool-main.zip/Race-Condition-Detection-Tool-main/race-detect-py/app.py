"""
Race Condition Detection Tool — Flask backend with user authentication.
Run:  python app.py    →  http://127.0.0.1:5000
"""

import json
import os
import sqlite3
from pathlib import Path

from flask import (Flask, flash, jsonify, redirect, render_template, request,
                   session, url_for)
from flask_login import (LoginManager, UserMixin, current_user, login_required,
                         login_user, logout_user)
from werkzeug.security import check_password_hash, generate_password_hash

from analyzer import EXAMPLES, analyze

BASE = Path(__file__).parent
DB_PATH = BASE / "users.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-prod-please")
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB upload limit

login_manager = LoginManager(app)
login_manager.login_view = "login"


# ---------- Database ----------
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)


# ---------- User model ----------
class User(UserMixin):
    def __init__(self, row):
        self.id = str(row["id"])
        self.username = row["username"]


@login_manager.user_loader
def load_user(user_id):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return User(row) if row else None


# ---------- Auth routes ----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u = (request.form.get("username") or "").strip()
        p = request.form.get("password") or ""
        if not u or len(u) > 64 or len(p) < 4:
            flash("Username required, password at least 4 characters.", "error")
            return redirect(url_for("register"))
        try:
            with db() as c:
                c.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (u, generate_password_hash(p)),
                )
            flash("Account created. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username already taken.", "error")
            return redirect(url_for("register"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = (request.form.get("username") or "").strip()
        p = request.form.get("password") or ""
        with db() as c:
            row = c.execute("SELECT * FROM users WHERE username = ?", (u,)).fetchone()
        if row and check_password_hash(row["password_hash"], p):
            login_user(User(row))
            return redirect(url_for("analyze_page"))
        flash("Invalid credentials.", "error")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("index"))


# ---------- App routes ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["GET"])
@login_required
def analyze_page():
    return render_template("analyze.html", examples=EXAMPLES)


import uuid

ANALYSIS_STORE = {}


@app.route("/api/analyze", methods=["POST"])
@login_required
def api_analyze():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip()
    language = data.get("language") or "auto"
    if not code:
        return jsonify({"error": "Empty code."}), 400
    if len(code) > 500_000:
        return jsonify({"error": "Code too large (max 500 KB)."}), 400
    report = analyze(code, language)

    analysis_id = str(uuid.uuid4())
    ANALYSIS_STORE[analysis_id] = {"report": report, "code": code}
    session["last_analysis_id"] = analysis_id

    return jsonify(report)


@app.route("/api/upload", methods=["POST"])
@login_required
def api_upload():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "No file."}), 400
    if not f.filename.lower().endswith(
        (".c", ".cpp", ".cc", ".py", ".java", ".go", ".rs")
    ):
        return jsonify({"error": "Unsupported file type."}), 400
    code = f.read().decode("utf-8", errors="replace")
    return jsonify({"code": code, "filename": f.filename})


@app.route("/results")
@login_required
def results_page():
    analysis_id = session.get("last_analysis_id")
    data = ANALYSIS_STORE.get(analysis_id, {})
    report = data.get("report")
    code = data.get("code", "")
    return render_template("results.html", report=report, code=code)


@app.route("/visualize")
@login_required
def visualize_page():
    analysis_id = session.get("last_analysis_id")
    data = ANALYSIS_STORE.get(analysis_id, {})
    report = data.get("report")
    return render_template("visualize.html", report=report)


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
