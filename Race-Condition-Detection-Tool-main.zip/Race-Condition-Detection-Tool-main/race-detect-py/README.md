# Race Condition Detection Tool (Python + Flask)

A full-stack web app that detects race conditions in multithreaded source code
(C, C++, Python, Java) and suggests synchronization fixes.

## Features
- User authentication (register / login / logout)
- Paste or upload source code (`.c .cpp .py .java`)
- Static + simulated dynamic analysis engine (pure Python)
- Detects RW / WW conflicts on shared variables
- Suggests mutexes, atomics, `synchronized`, `with lock:` etc.
- Visualizes thread access timeline
- Dark-neon responsive UI (HTML + CSS + vanilla JS)
- Example test cases included

## Install

```bash
python -m venv venv
# Windows: venv\Scripts\activate
source venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Then open: http://127.0.0.1:5000

## First use
1. Click **Register**, create an account.
2. Login.
3. Go to **Analyze**, paste code (or load an example), click **Analyze**.
4. View **Results** and **Visualize** pages.

## Project Structure
```
race-detect-py/
├── app.py                 # Flask app + routes + auth
├── analyzer.py            # Race condition analysis engine
├── requirements.txt
├── templates/             # Jinja2 HTML templates
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── analyze.html
│   ├── results.html
│   └── visualize.html
└── static/
    ├── css/style.css
    └── js/app.js
```
